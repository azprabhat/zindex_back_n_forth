<?php
    $image_name = $_FILES['myfile']['name'];
    $image_tmpname = $_FILES['myfile']['tmp_name'];
    for($i=0; $i< count($image_name); $i++)
    {
        $path = './uploaded/'.$image_name[$i].'';
        move_uploaded_file($image_tmpname[$i], $path);
    }
    echo 'uploaded';
?>