<style>
    .button-wrapper 
    {
        position: relative;
        overflow: hidden;
        display: inline-block;
        cursor: pointer
    }

    .btn 
    {
        border: 2px solid #00A0E3;
        color: #00A0E3;
        background-color: white;
        padding: 8px 20px;
        border-radius: 8px;
        font-size: 20px;
        font-weight: bold;
        cursor: pointer
    }
    .butn
    {
        background: #00A0E3;
        color: #fff
    }

    .button-wrapper input[type=file] 
    {
        font-size: 100px;
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        height: 100%;
        width: 100%;
        cursor: pointer
    }
</style>
<form action="upload.php" method="post" enctype="multipart/form-data">
    <div class="button-wrapper">
        <button type="button" class="btn">Choose a File</button>
        <input type="file" name="myfile[]" multiple accept="image/*" required />
    </div>
    <br><br>
    <button type="submit" class="btn butn">Upload Now</button>
</form>