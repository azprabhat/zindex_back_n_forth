<?php
    ob_start();
    session_start();

    define('PATH', '');

/* sql connetion parameter */
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASSWORD', '');
    define('DB_DATABASE', 'Database');
/* end */

    define('URL', 'http://localhost/new-near/');
    define('PHP_SELF', ''.$_SERVER['PHP_SELF'].'');
    define('SITENAME', 'Websitename');

/* system class object */
    require('system/System.php');
    $system = new System();
?>