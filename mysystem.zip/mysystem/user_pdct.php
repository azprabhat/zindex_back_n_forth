<?php 
    if($process == 'updct' && isset($_SESSION['userID']))
    {
        $allimages = $_FILES['image'];
        if(count($allimages) > 0)
        {
            $number = date('y').'192011';
            $unique_id = $system->uniqueId($dbcon, 'product_id', $number);
            $data = array(
                'image' => $allimages,
                'path' => 'assets/upload/'.$unique_id
            );
            $return_image = $system->upload_multiple($dbcon, $data);   
            if(count($return_image) > 0)
            {
                for($i=0;$i<count($return_image);$i++)
                {
                    $rimg = $return_image[$i];
                    $system->insert($dbcon, 'product_img', [ 'product_id' => $unique_id, 'image' => $rimg]);
                }
            }
            
            $data = array(
                'image' => $_FILES['mainimage'],
                'path' => 'assets/upload/'.$unique_id.'/main'
            );
            $main_img = $system->upload($dbcon, $data);
            
            $data = array(
                'cat_id' => $dbparam->real_escape_string($_POST['cat']),
                'scat_id' => $dbparam->real_escape_string($_POST['scat']),
                'name' => $dbparam->real_escape_string($_POST['title']),
                'product_id' => $unique_id,
                'description' => $dbparam->real_escape_string($_POST['desc']),
                'price' => $dbparam->real_escape_string($_POST['price']),
                'size' => $dbparam->real_escape_string($_POST['size']),
                'zipcode' => $dbparam->real_escape_string($_POST['zipcode']),
                'contacted' => $dbparam->real_escape_string($_POST['contacted']),
                'comment' => $dbparam->real_escape_string($_POST['comment']),
                'ad_link' => $dbparam->real_escape_string($_POST['ad-links']),
                'main_image' => $main_img,
                'user_id' => $_SESSION['userID'],
                'status' => $dbparam->real_escape_string($_POST['svp'])
            );
            
            $job_id = $system->insert($dbcon, 'product', $data);
            
            if($job_id)
            {
                $_SESSION['right']='Data Added';
                header('location: '.$php_self.'');
                exit;
            }
            else
            {
                $_SESSION['wrong']='Failed To Add Data';
                header('location: '.$php_self.'');
                exit;
            }
        }
        else
        {
            $_SESSION['wrong']='Select Images';
            header('location: '.$php_self.'');
            exit;
        }
    }

    if($process == 'uploadpdctmimg' && isset($_SESSION['userID']))
    {
        $pid = $dbparam->real_escape_string($_POST['pid']);
        $allimages = $_FILES['image'];
        if(count($allimages) > 0)
        {
            $data = array(
                'image' => $allimages,
                'path' => 'assets/upload/'.$pid
            );
            $return_image = $system->upload_multiple($dbcon, $data);   
            if(count($return_image) > 0)
            {
                for($i=0;$i<count($return_image);$i++)
                {
                    $rimg = $return_image[$i];
                    $system->insert($dbcon, 'product_img', [ 'product_id' => $pid, 'image' => $rimg]);
                }
            }
        }
        else
        {
            $_SESSION['wrong']='Select Images';
            header('location: '.$php_self.'');
            exit;
        }
    }
    
    if($process == 'updctmimg' && isset($_SESSION['userID']))
    {
        $pid = $dbparam->real_escape_string($_POST['pid']);
        $data = array(
            'image' => $_FILES['mainimage'],
            'path' => 'assets/upload/'.$pid.'/main'
        );
        $main_img = $system->upload($dbcon, $data);
        if($main_img)
        {
            $job_id = $system->update_where($dbcon, 'product', [ 'main_image' => $main_img ], [ 'product_id' => $pid, 'user_id' => $_SESSION['userID'] ]);
            if($job_id)
            {
                $_SESSION['right']='Image Uploaded';
                header('location: myaccount.php');
                exit;
            }
            else
            {
                $_SESSION['wrong']='Failed To Update Data';
                header('location: myaccount.php');
                exit;
            }
        }
        else
        {
            $_SESSION['wrong']='Failed To Upload Image Data';
            header('location: myaccount.php');
            exit;
        }
    }
    if($process == 'updt_updct' && isset($_SESSION['userID']))
    {
        $data = array(
            'cat_id' => $dbparam->real_escape_string($_POST['cat']),
            'scat_id' => $dbparam->real_escape_string($_POST['scat']),
            'name' => $dbparam->real_escape_string($_POST['title']),
            'description' => $dbparam->real_escape_string($_POST['desc']),
            'price' => $dbparam->real_escape_string($_POST['price']),
            'size' => $dbparam->real_escape_string($_POST['size']),
            'zipcode' => $dbparam->real_escape_string($_POST['zipcode']),
            'contacted' => $dbparam->real_escape_string($_POST['contacted']),
            'comment' => $dbparam->real_escape_string($_POST['comment']),
            'ad_link' => $dbparam->real_escape_string($_POST['ad-links']),
            'status' => $dbparam->real_escape_string($_POST['svp'])
        );
        $pid = $dbparam->real_escape_string($_POST['pid']);
        
        $job_id = $system->update_where($dbcon, 'product', $data, [ 'product_id' => $pid, 'user_id' => $_SESSION['userID'] ]);

        if($job_id)
        {
            $_SESSION['right']='Data Updated';
            header('location: myaccount.php');
            exit;
        }
        else
        {
            $_SESSION['wrong']='Failed To Update Data';
            header('location: myaccount.php');
            exit;
        }
    }
?>