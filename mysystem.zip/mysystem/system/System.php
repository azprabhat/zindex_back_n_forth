<?php
error_reporting(E_ALL ^ E_NOTICE); //report all error except notice
require_once('DB.php');
// setting configuration on db
DB::setDbConfiguration(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
// connect to db, get instance 
$dbcon = DB::getInstance();
$dbparam = $dbcon->getConnection();
/* jobs class */
class System 
{
    
/*-----------feedback variable---------*/
    
    public function __construct($arr_user = array()) { }   

/* common function to insert data into table */
    public function insert($dbcon, $table, $data)
    {
        $num = count($data); $i=0; $j=0;
        $sql_query = "insert into $table(";
        foreach($data as $k => $v)
        {
            if($i == $num - 1)
            {
                $sql_query .= $k;
            }
            else
            {
                $sql_query .= $k.',';
            }
            $i++;
        }
        $sql_query .= ") values(";
        foreach($data as $k => $v)
        {
            if($j == $num - 1)
            {
                $sql_query .= "'".$v."'";
            }
            else
            {
                $sql_query .= "'".$v."',";
            }
            $j++;
        }
        $sql_query .= ")";
        $job_id = $dbcon->executeUpdateQuery($sql_query); 
		return $job_id;
    }
    
/* common function to update data with where condition */
    public function update_where($dbcon, $table, $data, $where)
    {
        $num = count($data); $i=0; $j=0;
        $whr = count($where); $i=0; $j=0;
        $sql_query = "update $table set ";
        foreach($data as $k => $v)
        {
            if($i == $num - 1)
            {
                $sql_query .= $k. "='".$v."' ";
            }
            else
            {
                $sql_query .= $k. "='".$v."' , ";;
            }
            $i++;
        }
        $sql_query .= "where ";
        foreach($where as $k => $v)
        {
            if($j == $whr - 1)
            {
                $sql_query .= $k. "='".$v."' ";
            }
            else
            {
                $sql_query .= $k. "='".$v."' and ";
            }
            $j++;
        }
        $sql_query .= "";
        $job_id = $dbcon->executeSessQuery($sql_query); 
		return $job_id;
    }
    
/* common function to upload image */
    public function upload($dbcon, $data)
    {
        $number = date('y').'5522101';
        $image_ext =  array('jpg', 'jpeg', 'png', 'gif', 'JPG', 'JPEG');
        $img_name = $this->uniqueId($dbcon, 'image_id', $number);
        $tmp_name = $data['image']['tmp_name'];
        $main_pic = basename($data['image']['name']);
        $ext = pathinfo($main_pic,PATHINFO_EXTENSION);
        if(in_array($ext, $image_ext))
        {
            $image_name = $img_name.'.'.$ext;
            $target_file= $data['path'];
            if (!file_exists($target_file)) 
            {
                mkdir($target_file, 0777, true);
            }   
            $target_path = $target_file.'/'.$image_name;
            if(move_uploaded_file($tmp_name,$target_path))
            {
                return $image_name;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

/* multiple uploads */
    public function upload_multiple($dbcon, $data)
    {        
        $image_ext =  array('jpg', 'jpeg', 'png', 'gif', 'JPG', 'JPEG');
        $image_name = $data['image']['name'];
        $image_temp = $data['image']['tmp_name'];
        $number = date('y').'5522101';
        for( $i=0; $i < count($image_name); $i++)
        {
            $tmp_name = $image_temp[$i];
            $main_pic = basename($image_name[$i]);
            $ext = pathinfo($main_pic,PATHINFO_EXTENSION);
            if(in_array($ext, $image_ext))
            {
                $uqimgname = $this->uniqueId($dbcon, 'image_id', $number);
                $image_return_name = $uqimgname.'.'.$ext;
                $target_file= $data['path'];
                if (!file_exists($target_file)) 
                {
                    mkdir($target_file, 0777, true);
                }   
                $target_path = $target_file.'/'.$image_return_name;
                if(move_uploaded_file($tmp_name,$target_path))
                {
                    $imgs[$i] = $image_return_name;
                }
            }
        }
        return $imgs;
    }
    
/* get data by where condition */
    public function getbywhere($dbcon, $select, $table, $where)
    {
        $num = count($where); $i=0;
        $sql_query = "select $select from $table where ";
        foreach($where as $k => $v)
        {
            if($i == $num - 1)
            {
                $sql_query .= $k. "='".$v."'";
            }
            else
            {
                $sql_query .= $k. "='".$v."' and ";
            }
            $i++;
        }
        $sql_query .= "";
        $job_id = $dbcon->executeQuery($sql_query); 
		return $job_id;
    }
    
/* get data by where condition */
    public function fetch($dbcon, $qry = false, $table = false)
    {
        if($table) $sql_query = "select * from $table";
        if($qry)   $sql_query = "$qry";;
        $job_id = $dbcon->executeQuery($sql_query); 
		return $job_id;
    }
    
/* common function of delete data from table by id */
    public function delete($dbcon, $table , $where)
    {        
        $num = count($where); $i=0;
        $sql_query = "delete from $table where ";
        foreach($where as $k => $v)
        {
            if($i == $num - 1)
            {
                $sql_query .= $k. "='".$v."'";
            }
            else
            {
                $sql_query .= $k. "='".$v."' and ";
            }
            $i++;
        }
        $sql_query .= "";
        $job_id = $dbcon->executeSessQuery($sql_query); 
		return $job_id;
    }
    
/* make url */
    public function name_url($dbcon, $name)
    {
        $url = strtolower(implode('-',explode(' ',$name)));
        $url = str_replace(array( '(', ')','!','&',' ','  ','?','*','/','.',',','%'), '', $url);
		return $url;
    }

/* document series */
    public function uniqueId($dbcon, $name,$numb)
    {
        $job_id = $this->getDocSeries($dbcon,$name);
        $value = $job_id[0]->last_number;
        if($job_id)
        {
            $numb = $value + 1;
            $this->updateDocSeries($dbcon,$name,$numb);
        }
        else
        {
            $value = $numb;
            $numb = $numb + 1;                                                  
            $this->setDocSeries($dbcon,$name,$numb);
        }
        return $value;
    }
    
    public function getDocSeries($dbcon, $name)
    {
		$sql_query = "select * from doc_series where doc_name='$name'";
		$job_id = $dbcon->executeQuery($sql_query); 
		return $job_id;
    }
    
    public function setDocSeries($dbcon, $name,$numb)
    {
		$sql_query = "insert into doc_series(doc_name,last_number)values('$name','$numb')";
		$job_id = $dbcon->executeUpdateQuery($sql_query); 
		return $job_id;
    }
    
    public function updateDocSeries($dbcon, $name,$numb)
    {
		$sql_query="update doc_series set last_number='$numb' where doc_name='$name'";
		$job_id = $dbcon->executeSessQuery($sql_query);	
		return $job_id;
    }
}
?>