<?php
class DB {
	// query to execute
	public $query = null;

	protected $connection = null;
	protected static $configuration = array();

    private static $instance = null;

	private $results = null;
	// transaction check
	private $transaction = false;

	/**
	 * Connecting to db, if error throw exeption
	 */
    private function __construct() {
    	$this->connection = new mysqli(self::$configuration['db_host'], self::$configuration['db_user'], self::$configuration['db_password'], self::$configuration['db_name']);

		if ( !empty($this->connection->connect_errno)) {
		    throw new Exception('Connect failed, error: ' . $this->connection->connect_error);
		}
    }

	/**
	 * Just nice closing connection to current db
	 */
    public function __destruct() {
		//echo "connection closing";die;
		//$this->connection->close();
    }

	/**
	 * Creating a singleton of current db connection
	 */
    public static function getInstance() {
        if (empty(self::$instance[self::$configuration['db_host']][self::$configuration['db_name']])) {
            self::$instance[self::$configuration['db_host']][self::$configuration['db_name']] = new self();
        }
        return self::$instance[self::$configuration['db_host']][self::$configuration['db_name']];
    }

	/**
	 * Giving a freedom of doing what you want with mysqli connection
	 */
    public function getConnection() {
    	//return self::$connection;
        return $this->connection;
    }

	/**
	 * Setting configuration to db
	 *
	 * @param string $pDbHost
	 * @param string $pUser
	 * @param string $pPassword
	 * @param mixed $pDbName (optional)
	 */
    public static function setDbConfiguration($pDbHost, $pUser, $pPassword, $pDbName = null) {
		self::$configuration = array('db_host' => $pDbHost, 'db_user' => $pUser, 'db_password' => $pPassword, 'db_name' => $pDbName);
    }
	
	/**
	 * Executing query on db
	 */
	//used for select queries. It will return the array of objects
	public function executeQuery($query) {
		$this->results = $this->connection->query($query) or die($this->connection->error.$query);

		if( $this->results->num_rows > 0 ) {
		$rowqry = array();
			while($row = $this->results->fetch_object()) {
				array_push($rowqry,$row);
			}
			return $rowqry;
		} else {
			return false;
		}
	}
  
	public function executeSessQuery($query) {
		$this->results = $this->connection->query($query) or die($this->connection->error.$query);
		return $this->results;
	}

//used for insert and update queries which do not return any value	
	public function executeNonQuery($query) {
		$this->results = $this->connection->query($query) or die($this->connection->error." SQL: ".$query);
		$item_id = $this->connection->insert_id;
		return $item_id;
	}
  
  //used for insert and update queries which do not return any value	
	public function executeUpdateQuery($query) {
		$this->results = $this->connection->query($query) or die($this->connection->error." SQL: ".$query);
		$item_id = $this->connection->affected_rows;
		return $item_id;
	}
  
//returns the count of records
  public function executeQueryCountRecords($query) {
		$this->results=mysqli_query($this->connection,$query) or die(mysql_error().$query);
		return mysqli_num_rows($this->results);
	}
	
} //End db class

?>